//CommonJS 방식
//const data = require("./module/basic-data.js")
//ESM 방식
import data from "./module/basic-data.js"

console.dir(data)
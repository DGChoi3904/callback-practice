function one () {
  return 1;
}

function twoReturnString () {
  return "1";
}

two() === "1"; // true

function isThree() {
  return true;
}